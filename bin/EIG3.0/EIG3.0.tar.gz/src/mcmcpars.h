
  double thp1=1.0, thp2 = 5.0 ;  /* params for theta */
  double thxp1=1.0, thxp2 = 10.0 ;  /* params for theta X  */
  double thxp0 = 40 ;  /* cross term */
/* -1 is default value (=0 logically)  */
  
  double lp1 = 10.2, lp2 = 2 ;  
  double lxp1 = 10.2, lxp2 = 2 ;  

  double priorlmean = 6 ;  
  double priorlmsig  = 5 ;  
/* hyperprior on mean, s.dev for gamma prior on lambda */

  double qtrbase = 0.0 ;

  double loclip = -20.0 ;
  double hiclip =  15.0 ;

  double a1 = 2, b1= 8 ;
  double aa2 = 2, bb2 = 14, cc2 = 85 ;  
  double p1 = 18, psi1 = 3 ;
/* for toys */

  double muval = 0.0, tmumean = 0.2, muval1 ;
/* for bridge sampler */

  int pubxindiv = -1  ;
  int alkesmode = NO ;
  int malexhet = NO ;
  int familynames  = YES ;

  int decim = 0 , dmindis = 200000, dmaxdis = 500000 ; // decimation parameters
  int hashcheck = YES ;
  int outputall = NO ;
  int sevencolumnped = NO ;

  FILE *fstdetails  = NULL;

